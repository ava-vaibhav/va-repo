import { durable } from '@versori/run';
import { avalaraProxyWorkflow } from './workflows/avalara-proxy';

async function main(): Promise<void> {
  // Initialise the DurableInterpreter - the default choice for production workflows
  const mi = await durable.DurableInterpreter.newInstance();

  // Register the Avalara proxy workflow
  mi.register(avalaraProxyWorkflow);

  // Start the interpreter to serve the webhook endpoint
  await mi.start();
}

main().then().catch((err) => console.error('Failed to run main()', err));
