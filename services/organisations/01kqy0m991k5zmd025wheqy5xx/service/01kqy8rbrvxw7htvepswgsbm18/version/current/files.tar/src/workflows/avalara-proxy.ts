import { webhook, http } from '@versori/run';

/**
 * REST API Proxy Workflow for Avalara 1099 Issuers
 * 
 * This workflow acts as a proxy endpoint that:
 * 1. Accepts incoming REST API requests with Bearer token authentication
 * 2. Forwards the request to Avalara's 1099 issuers endpoint
 * 3. Returns the Avalara API response directly to the caller
 * 
 * Usage:
 * POST/GET to webhook endpoint with Authorization: Bearer <token> header
 */
export const avalaraProxyWorkflow = webhook('avalara-1099-issuers', { 
  response: { mode: 'sync' } 
})
  .then(
    http('fetch-avalara-issuers', { connection: 'source_rest_api' }, async ({ fetch, log, data }) => {
      // Log the complete data structure for debugging
      log.info('Webhook received', { 
        dataType: typeof data,
        dataKeys: data ? Object.keys(data) : [],
        fullData: JSON.stringify(data)
      });

      // In versori-run webhooks, headers are typically at the root level of data
      // Try all possible locations and formats
      let authHeader: string | undefined;
      
      // Check root level (most common for versori-run webhooks)
      if (typeof data === 'object' && data !== null) {
        authHeader = (data as any).authorization || (data as any).Authorization;
      }
      
      // Check nested headers object
      if (!authHeader && data && typeof data === 'object') {
        const headers = (data as any).headers;
        if (headers && typeof headers === 'object') {
          authHeader = headers.authorization || headers.Authorization;
        }
      }
      
      // Check request.headers object
      if (!authHeader && data && typeof data === 'object') {
        const request = (data as any).request;
        if (request && typeof request === 'object' && request.headers && typeof request.headers === 'object') {
          authHeader = request.headers.authorization || request.headers.Authorization;
        }
      }

      log.info('Header extraction result', {
        foundAuth: !!authHeader,
        authHeaderLength: authHeader?.length || 0
      });
      
      if (!authHeader) {
        log.error('Missing Authorization header', { 
          receivedData: JSON.stringify(data, null, 2)
        });
        throw new Error('Authorization header is required');
      }

      log.info('Forwarding request to Avalara 1099 issuers endpoint');

      // Call the Avalara API with the provided Bearer token
      const response = await fetch('/avalara1099/1099/issuers', {
        method: 'GET',
        headers: {
          'accept': 'application/json',
          'avalara-version': '2.0.0',
          'authorization': authHeader
        }
      });

      if (!response.ok) {
        const errorText = await response.text();
        log.error('Avalara API request failed', { 
          status: response.status, 
          statusText: response.statusText,
          error: errorText
        });
        throw new Error(`Avalara API request failed: ${response.status} ${response.statusText}`);
      }

      const responseData = await response.json();
      log.info('Successfully retrieved Avalara 1099 issuers data', { 
        recordCount: responseData.value?.length || 0 
      });

      return responseData;
    })
  );
